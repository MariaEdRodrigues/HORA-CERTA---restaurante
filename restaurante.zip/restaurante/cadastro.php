<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifique se todos os campos foram preenchidos
    if (isset($_POST["nome"]) && isset($_POST["email"]) && isset($_POST["senha"]) && isset($_POST["telefone"]) && isset($_POST["endereco"])) {
        // Conexão com o banco de dados (inclua a sua conexão aqui)
        include("config.php");

        // Captura os dados do formulário
        $nome = $_POST["nome"];
        $email = $_POST["email"];
        $senha = $_POST["senha"];
        $telefone = $_POST["telefone"];
        $endereco = $_POST["endereco"];

        // Prepara e executa a consulta SQL para inserir os dados
        $sql = "INSERT INTO usuarios (nome, email, senha, telefone, endereco) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("sssss", $nome, $email, $senha, $telefone, $endereco);

        if ($stmt->execute()) {
            echo "Cadastro realizado com sucesso!";
            //header("Location: index.php");
        } else {
            echo "Erro ao cadastrar: " . $conexao->error;
        }

        // Fecha a conexão
        $stmt->close();
        $conexao->close();
    } else {
        echo "Por favor, preencha todos os campos do formulário.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página de Cadastro</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .register-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
            width: 400px;
            margin: 50px auto;
            padding: 20px;
            text-align: center;
        }
        .register-container h2 {
            color: #333;
        }
        .register-form {
            text-align: left;
            margin-top: 20px;
        }
        .register-form label {
            display: block;
            margin-bottom: 5px;
        }
        .register-form input[type="text"],
        .register-form input[type="email"],
        .register-form input[type="password"],
        .register-form input[type="tel"] {
            width: 95%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .register-form input[type="submit"] {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .register-form input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <img src="./img/LOGO.png" alt="Hora Certa Logo" width="120" height="70" class="d-inline-block align-text-top">
        <h2>CADASTRE-SE</h2>
        <form class="register-form" method="post" action="">
            <label for="name">Nome:</label>
            <input type="text" id="nome" name="nome" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Senha:</label>
            <input type="password" id="senha" name="senha" required>
            <label for="phone">Telefone:</label>
            <input type="tel" id="telefone" name="telefone" required>
            <label for="address">Endereço:</label>
            <input type="text" id="endereco" name="endereco" required>
            <input type="submit" value="Cadastrar">
        </form>
    </div>
</body>
</html>