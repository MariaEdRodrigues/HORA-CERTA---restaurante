<?php
include('config.php'); // Inclua o arquivo de configuração

// Seu código PHP aqui
?>

<?php
include "header.php";
?>
<section id="carrossel" class="container-fluid mt-3">
    <?php
    include "carrossel.php";
    ?>
</section>
<div class="container">
    <section id="cardsprincipal">
        <?php
        include "cardsprincipal.php";
        ?>
    </section>
</div>
<?php
include "footer.php";
?>