<?php
include('config.php'); // Inclua o arquivo de configuração

$mensagem = ""; // Inicialize a variável de mensagem vazia

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Processamento do formulário aqui
    $nome = mysqli_real_escape_string($conexao, $_POST['nome']);
    $telefone = mysqli_real_escape_string($conexao, $_POST['telefone']);
    $cpf = mysqli_real_escape_string($conexao, $_POST['cpf']);
    $cep = mysqli_real_escape_string($conexao, $_POST['cep']);
    $rua = mysqli_real_escape_string($conexao, $_POST['rua']);
    $bairro = mysqli_real_escape_string($conexao, $_POST['bairro']);
    $cidade = mysqli_real_escape_string($conexao, $_POST['cidade']);
    $numero = mysqli_real_escape_string($conexao, $_POST['numero']);
    $formas_pagamento = mysqli_real_escape_string($conexao, $_POST['formas_pagamento']);

    // Inserir os dados na tabela de pedidos (ou fazer o processamento desejado)
    $query_inserir = "INSERT INTO pedidos (nome, telefone, cpf, cep, rua, bairro, cidade, numero, formas_pagamento) VALUES ('$nome', '$telefone', '$cpf', '$cep', '$rua', '$bairro', '$cidade', '$numero', '$formas_pagamento')";

    if (mysqli_query($conexao, $query_inserir)) {
         $mensagem = "Pedido realizado com sucesso!";
    } else {
         $mensagem = "Erro ao processar o pedido: " . mysqli_error($conexao);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário de Delivery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }

        h1 {
            text-align: center;
            color: #FFA500;
        }

        .form-group {
            margin-bottom: 20px;
            margin-right: 20px;
        }

        label {
            font-weight: bold;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        select.form-control {
            width: 100%;
        }

        .btn {
            background-color: #FFA500;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            display: inline-block;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Formulário de Delivery</h1>
        <form action="" method="POST">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="telefone">Telefone:</label>
                <input type="tel" id="telefone" name="telefone" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="cpf">CPF:</label>
                <input type="text" id="cpf" name="cpf" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="cep">CEP:<span><i class="fas fa-search" onclick="preencherEndereco()" style="cursor: pointer;"></i></span></label>
                <input type="text" id="cep" name="cep" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="rua">Rua:</label>
                <input type="text" id="rua" name="rua" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="bairro">Bairro:</label>
                <input type="text" id="bairro" name="bairro" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="cidade">Cidade:</label>
                <input type="text" id="cidade" name="cidade" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="numero">Número:</label>
                <input type="text" id="numero" name="numero" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="formas_pagamento">Formas de Pagamento:</label>
                <select id="formas_pagamento" name="formas_pagamento" class="form-control" required>
                    <option value="dinheiro">Dinheiro</option>
                    <option value="cartao_credito">Cartão de Crédito</option>
                    <option value="cartao_debito">Cartão de Débito</option>
                    <option value="pix">PIX QR Code</option>
                </select>
            </div>

            <button type="submit" class="btn">Enviar Pedido</button>
        </form>

        <!-- Mensagem de confirmação ou erro -->
        <p><?php echo $mensagem; ?></p>
    </div>

    <script>
        function preencherEndereco() {
            var cep = document.getElementById("cep").value;
            if (cep.length == 8) { // Verifica se o CEP possui 8 dígitos
                fetch("https://viacep.com.br/ws/" + cep + "/json/")
                    .then(response => response.json())
                    .then(data => {
                        if (!data.erro) {
                            document.getElementById("rua").value = data.logradouro;
                            document.getElementById("bairro").value = data.bairro;
                            document.getElementById("cidade").value = data.localidade;
                        }
                    })
                    .catch(error => console.log(error));
            }
        }
    </script>
</body>

</html>
