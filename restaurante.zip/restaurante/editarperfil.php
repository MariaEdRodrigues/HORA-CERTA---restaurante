<?php
include("config.php"); // Inclua as configurações do banco de dados
include("userfunctions.php");

session_start();

// Verifique se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php"); // Redirecione para a página de login se o usuário não estiver logado
    exit();
}

// Crie uma conexão com o banco de dados
$mysqli = new mysqli($db_host, $db_user, $db_password, $db_name);

// Verifique a conexão
if ($mysqli->connect_error) {
    die("Erro de conexão com o banco de dados: " . $mysqli->connect_error);
}

// Obtenha o ID do usuário logado
$user_id = $_SESSION['usuario_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Processar o formulário de edição e atualizar as informações no banco de dados

    // Você pode validar os campos do formulário aqui, como verificar se o email é único, etc.
    // Certifique-se de aplicar validação adequada.

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];

    // Se o campo de imagem estiver preenchido, você pode fazer o upload e atualizar a foto de perfil
    if (isset($_FILES['imagem']['name']) && !empty($_FILES['imagem']['name'])) {
        $imagem_temp = $_FILES['imagem']['tmp_name'];
        $imagem_nome = $_FILES['imagem']['name'];
        $imagem_path = "caminho/para/salvar/a/imagem/" . $imagem_nome; // Substitua pelo caminho correto
        move_uploaded_file($imagem_temp, $imagem_path);
        // Atualize a coluna de imagem no banco de dados com o novo caminho da imagem
        $sql = "UPDATE usuarios SET nome = ?, email = ?, telefone = ?, imagem = ? WHERE usuario_id = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("ssssi", $nome, $email, $telefone, $imagem_path, $user_id);
    } else {
        // Se o campo de imagem não estiver preenchido, atualize as outras informações
        $sql = "UPDATE usuarios SET nome = ?, email = ?, telefone = ? WHERE usuario_id = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("sssi", $nome, $email, $telefone, $user_id);
    }

    // Execute a atualização
    if ($stmt->execute()) {
        header("Location: perfil.php"); // Redirecione de volta para a página de perfil após a edição
        exit();
    } else {
        echo "Erro ao salvar as alterações no perfil.";
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FFC081;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; /* Centralize horizontalmente */
            align-items: center; /* Centralize verticalmente */
            min-height: 100vh; /* Garante que a página ocupe a altura total da janela do navegador */
        }

        .container {
            max-width: 600px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        form {
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        button {
            background-color: #F29F05;
            color: #fff;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #D2691E;
        }

        a {
            text-decoration: none;
            color: #007BFF;
            display: inline-block;
            margin-top: 10px;
        }
    </style>
    <title>Editar Perfil</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Editar Perfil</h1>
        <form action="salvar_edicao.php" method="POST" enctype="multipart/form-data">

            
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" value="<?php echo $profileInfo['nome']; ?>" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" value="<?php echo $profileInfo['email']; ?>" required>

            <label for="telefone">Telefone:</label>
            <input type="tel" name="telefone" id="telefone" value="<?php echo $profileInfo['telefone']; ?>" required>

            <button type="submit">Salvar</button>
        </form>
        <a href="perfil.php">Voltar para o Perfil</a>
    </div>
</body>
</html>
