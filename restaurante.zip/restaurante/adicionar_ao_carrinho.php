<?php
// Inicie ou retome a sessão para acessar o carrinho
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['produto_id']) && isset($_POST['nome']) && isset($_POST['preco'])) {
        $produto_id = $_POST['produto_id'];
        $nome = $_POST['nome'];
        $preco = $_POST['preco'];

        // Verifique se o carrinho já existe na sessão e, se não, crie um array vazio
        if (!isset($_SESSION['carrinho'])) {
            $_SESSION['carrinho'] = [];
        }

        // Adicione o produto ao carrinho
        $item = [
            'id' => $produto_id,
            'nome' => $nome,
            'preco' => $preco,
            // Outros detalhes do produto
        ];

        // Mensagem de depuração
        echo "Item com ID $produto_id adicionado ao carrinho.";

        // Adicione esta linha para depurar
        var_dump($_SESSION['carrinho']);

        // Redirecione de volta à página do cardápio
        header("Location: cardapio.php");
        exit;
    }
}

// Se não houver dados válidos para processar, redirecione para a página do cardápio
header("Location: cardapio.php");
exit;
?>
