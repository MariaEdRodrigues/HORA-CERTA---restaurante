<!DOCTYPE html>
<html>
<head>
    <style>
         body {
            margin: 0;
            padding: 0;
        }
        /* Adicione o estilo para o topo fixo */
        #top-menu {
            /*position: fixed;*/
            top: 0;
            width: 100%;
            background-color: #F0E5CF;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            z-index: 1000; /* Certifique-se de que o topo fique acima do conteúdo rolável */
        }
        body {
            margin: 0;
            padding: 0;
        }
        #top-menu {
            background-color: #F0E5CF;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        #logo {
            width: 100px; /* Defina o tamanho da logo */
            height: auto;
            margin-right: 1000px;
        }
        #menu-links a {
            color: #000203;
            margin: 0 15px;
            text-decoration: none;
        }
        #delivery-button {
            background-color: #E87800;
            color: white;
            border: none;
            border-radius: 25px;
            padding: 5px 15px;
            text-decoration: none;
        }    
        #cart-icon::before {
            content: '\1F6D2'; /* Código Unicode para o ícone de carrinho de compras */
            font-size: 24px; /* Tamanho do ícone */
            margin-right: 5px; /* Espaçamento à direita do ícone */
        }
        #profile-icon {
            font-size: 30px; /* Tamanho do ícone de perfil */
            color: #E87800; /* Cor do ícone de perfil */
            margin-right: 5px; /* Margem à direita do ícone de perfil para separá-lo do logotipo */
        }

    </style>
</head>
<body>

<div id="top-menu">
<a href="perfil.php"><div id="profile-icon">&#128101;</div></a>
    
<a href="index.php"><img id="logo" src="img/LOGO.png" alt="Logo do Restaurante"></a>
    <div id="menu-links">
        <a href="cardapio.php">Cardápio</a>
        <a href="contato.php">Contato</a>
        <a href="pedidos.php" id="delivery-button">Delivery</a>
        <a href="carrinho.php" id="cart-icon"></a>
    </div>
</div>

<!-- Conteúdo da página aqui -->

</body>
</html>
