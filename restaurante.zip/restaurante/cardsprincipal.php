<!DOCTYPE html>
<html>

<head>
  <title>Cards Centralizados</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .custom-title {
      font-size: 24px;
      font-weight: bold;
      color: #333;
      text-align: center;
      padding: 20px 0;
    }

    /* Estilo para o card */
    .card {
      width: 100%;
      height: 500px;
      border-radius: 5px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      margin-bottom: 10px;
      margin-right: 50px;
    }

    .card-2 {
      width: 100%;
      height: 100%;
      border-radius: 5px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      margin-bottom: 10px;
      margin-right: 50px;
    }

    .div {
      width: 100%;
      height: 500px;
      border-radius: 5px;
      margin-right: 100px;
    }

    /* Estilo para a imagem de fundo */
    .card-img {
      width: 100%;
      height: 450px;
      /* Altura da imagem de fundo */
      background-size: cover;
      background-position: center;
      position: absolute;
    }

    /* Estilo para a sobreposição do card */
    .card-overlay {
      background-color: rgba(0, 0, 0, 0.7);
      /* Fundo semi-transparente preto */
      padding: 10px;
      text-align: center;
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      color: #fff;
    }

    /* Estilo para o título do card */
    .card-title {
      font-size: 20px;
      margin-bottom: 10px;
    }

    /* Estilo para o botão de reserva */
    .btn-reserva {
      display: inline-block;
      padding: 10px 20px;
      background-color: #007bff;
      /* Cor de fundo do botão */
      color: #fff;
      /* Cor do texto do botão */
      text-decoration: none;
      border-radius: 5px;
      transition: background-color 0.3s ease;
    }

    .btn-reserva:hover {
      background-color: #0056b3;
      /* Cor de fundo do botão quando hover */
    }
  </style>
</head>

<body>
  <div class="container">
    <h1 class="custom-title">CONFIRA NOSSOS PRATOS EXECUTIVOS</h1>
    <!-- <div class="row row-cols-1 row-cols-md-3 g-4"> -->
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <img src="img/prato-executivo.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Filé mignon</h5>
            <p class="card-text">Nosso Filé Mignon Gourmet é grelhado à perfeição, proporcionando uma crosta dourada e um interior incrivelmente macio. Acompanhado por uma deliciosa salada e batata frita, este prato é uma experiência memorável para os amantes de carne.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="img/strogonoff.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">strogonoff de carne</h5>
            <p class="card-text">Nosso strogonoff de carne é preparado com pedaços suculentos de carne, cozidos lentamente em um molho cremoso e saboroso. Servido com arroz branco soltinho, é uma explosão de conforto e sabor em cada garfada.</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card">
          <img src="img/executivo-ovo.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Frango grelhado</h5>
            <p class="card-text">Uma combinação clássica de sabores e texturas que satisfaz a qualquer hora. Acompanhado por um ovo frito de gema dourada e cremosa. Complementado com um toque de ervas frescas, é uma refeição reconfortante que agrada a todos os paladares.</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Card com imagem de fundo -->
    <div class="row mb-2">
      <div class="col-sm-6">
        <div class="card card-2">
          <div class="card-img" style="background-image: url('img/reserva.jpg');">
            <div class="card-overlay">
              <h3 class="card-title">Título do Evento</h3>
              <a href="reservas.php" class="btn btn-reserva">Reservar</a>
            </div>
          </div>
        </div>
      </div>
      <!-- <div class="col-md-2"></div> -->
      <div class="col-sm-6">
        <div class="card card-2">
          <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d3666.8325119669103!2d-49.376741400000036!3d-23.2127737!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1spt-BR!2sus!4v1693317826933!5m2!1spt-BR!2sus" width="525" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>






  </div>


</body>

</html>