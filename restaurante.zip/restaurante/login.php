<?php
session_start(); // Inicie a sessão

include('config.php'); // Inclua o arquivo de configuração

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifique se o usuário e a senha foram fornecidos
    if (isset($_POST["email"]) && isset($_POST["senha"])) {
        // Inclua o arquivo de configuração com a conexão com o banco de dados
        include("config.php");

        // Captura os dados do formulário
        $email = $_POST["email"];
        $senha = $_POST["senha"];

        // Prepara e executa a consulta SQL para autenticar o usuário
        $sql = "SELECT user_id FROM usuarios WHERE email = ? AND senha = ?";
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ss", $email, $senha);
        $stmt->execute();
        $result = $stmt->get_result();

        // Verifica se o usuário foi autenticado
        if ($result->num_rows == 1) {
            // O usuário foi autenticado com sucesso, obtenha o ID do usuário
            $row = $result->fetch_assoc();
            $usuario_id = $row["user_id"];

            // Defina a variável de sessão usuario_id
            $_SESSION['usuario_id'] = $usuario_id;

            // Redirecione para a página de perfil ou outra página de destino
            header("Location: perfil.php");
            echo "Voce esta logado!!!!!.";
            exit();
        } else {
            // Autenticação falhou, exiba uma mensagem de erro
            echo "Usuário ou senha incorretos.";
        }

        // Fecha a conexão
        $stmt->close();
        $conexao->close();
    } else {
        echo "Por favor, preencha todos os campos do formulário.";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>LOGIN</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .login-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
            width: 300px;
            margin: 100px auto;
            padding: 60px;
            text-align: center;
        }
        .login-container h2 {
            color: #333;
        }
        .login-form {
            text-align: left;
            margin-top: 20px;
        }
        .login-form label {
            display: block;
            margin-bottom: 5px;
        }
        .login-form input[type="text"],
        .login-form input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .login-form input[type="submit"] {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .login-form input[type="submit"]:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <img src="./img/LOGO.png" alt="Hora Certa Logo" width="120" height="70" class="d-inline-block align-text-top">
        <h2>FAÇA SEU LOGIN</h2>
        <form class="login-form" method="post" action="">
            <label for="email">Usuário:</label>
            <input type="text" id="email" name="email" required>
            <label for="password">Senha:</label>
            <input type="password" id="password" name="senha" required>
            <input type="submit" value="Entrar">
        </form>
        <p>Não tem conta?<a href="cadastro.php">Cadastre-se!</a></p>
    </div>
</body>
</html>
