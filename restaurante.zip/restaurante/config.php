<?php
// Configuração do banco de dados
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'restaurante';

// Crie uma conexão com o banco de dados
$conexao = new mysqli($db_host, $db_user, $db_password, $db_name);

// Verifique a conexão
if ($conexao->connect_error) {
    die("Erro de conexão com o banco de dados: " . $conexao->connect_error);
}
?>