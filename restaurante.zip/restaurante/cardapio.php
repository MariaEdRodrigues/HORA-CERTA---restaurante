<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Cardápio do Restaurante</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            background-color: #FFDAB9;
        }

        .menu {
            max-width: 900px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .menu h1 {
            text-align: center;
        }

        .menu-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .menu-item {
            flex: 1;
            margin: 10px;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            width: 48%;
            display: flex; /* Adicione display flex para organizar os elementos lado a lado */
        }

        .menu-item img {
            max-width: 150px;
            max-height: 150px; /* Defina uma altura máxima para manter as imagens proporcionais */
            margin-right: 20px;
        }

        .menu-details {
            flex: 1; /* Preencha todo o espaço restante na horizontal */
        }

        .menu-item h2 {
            margin: 0;
        }

        .price {
            color: #ff5733;
            font-weight: bold;
        }

        .add-to-cart {
            background-color: #ff5733;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
<?php include('topocard.php'); ?>
<div style="margin-top: 100px;"></div>
<div class="menu">
    <h1>Itens Promocionais</h1>
    <div class="menu-row">
    <?php
    session_start(); // Certifique-se de iniciar a sessão para acessar a variável de carrinho

    // Sua configuração de conexão com o banco de dados
    $db_host = 'localhost';
    $db_user = 'root';
    $db_password = '';
    $db_name = 'restaurante';
    
    // Crie uma conexão com o banco de dados
    $conexao = new mysqli($db_host, $db_user, $db_password, $db_name);
    
    // Verifique a conexão
    if ($conexao->connect_error) {
        die("Erro de conexão com o banco de dados: " . $conexao->connect_error);
    }
    
    // Consulta SQL para recuperar itens do cardápio
    $query = "SELECT produto_id, nome, descricao, preco, imagem FROM produtos WHERE categoria = 'Promocao'";
    $resultado = $conexao->query($query);
    
    if ($resultado->num_rows > 0) {
        while ($row = $resultado->fetch_assoc()) {
            // Processar os dados do banco de dados aqui
            $nome = $row['nome'];
            $descricao = $row['descricao'];
            $preco = $row['preco'];
            $imagem = $row['imagem'];
            $produto_id = $row['produto_id']; // Adiciona o ID do produto
    
            // Exibir os dados do cardápio com botão "Adicionar ao Carrinho"
            echo "<div class='menu-item'>";
            echo "<img src='$imagem' alt='$nome' width='200'>";
            echo "<div class='menu-details'>";
            echo "<h2>$nome</h2>";
            echo "<p>$descricao</p>";
            echo "<p class='price'>$" . number_format($preco, 2) . "</p>";
            
            // Adiciona um evento de clique para adicionar ao carrinho
            echo "<button class='add-to-cart' data-id='$produto_id'><i class='fas fa-shopping-cart'></i> Adicionar ao Carrinho</button>";
    
            echo "</div>";
            echo "</div>";
        }
    
        // Liberar o resultado da consulta
        $resultado->close();
    } else {
        echo "Nenhum item encontrado no cardápio.";
    }
    
    // Fechar a conexão com o banco de dados
    $conexao->close();
    
    ?>
</div>

<script>
    // Função para adicionar ao carrinho
    function adicionarAoCarrinho(id) {
        // Crie um objeto que representa o item a ser adicionado
        var item = {
            produto_id: id
        };

        // Inicie ou retome a sessão para acessar o carrinho
        <?php
        if (!isset($_SESSION['carrinho'])) {
            echo "var carrinho = [];\n";
        } else {
            echo "var carrinho = " . json_encode($_SESSION['carrinho']) . ";\n";
        }
        ?>

        // Adicione o item ao carrinho
        carrinho.push(item);

        // Atualize a variável de sessão com o carrinho
        <?php
            echo "\$_SESSION['carrinho'] = carrinho;";
        ?>

        // Exiba uma mensagem de sucesso (você pode personalizar isso)
        alert('Item adicionado com sucesso ao carrinho.');

        // Redirecione de volta à página do cardápio
        window.location.href = 'cardapio.php';
    }

    var botoesAdicionarAoCarrinho = document.querySelectorAll(".add-to-cart");
    botoesAdicionarAoCarrinho.forEach(function (botao) {
        botao.addEventListener("click", function () {
            var id = botao.getAttribute("data-id");
            adicionarAoCarrinho(id);
        });
    });
</script>
</body>
</html>
