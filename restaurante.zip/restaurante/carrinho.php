<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Carrinho de Compras</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }

        h1 {
            text-align: center;
            color: #FFA500;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #FFA500;
            color: #fff;
        }

        .total {
            text-align: right;
            font-weight: bold;
        }

        .checkout-button {
            background-color: #FFA500;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<?php
include "menutop.php";
?>

<div class="container">
    <h1>Carrinho de Compras</h1>
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Quantidade</th>
                <th>Preço Unitário</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            session_start();
            $total = 0;

            // Verifique se há itens no carrinho
            if (!empty($itensDoCarrinho)) {
                foreach ($itensDoCarrinho as $item) {
                    $nome = $item['nome'];
                    $quantidade = $item['quantidade'];
                    $preco = $item['preco'];
                    $subtotal = $quantidade * $preco;
                    $total += $subtotal;

                    echo "<tr>";
                    echo "<td>$nome</td>";
                    echo "<td>$quantidade</td>";
                    echo "<td>R$ " . number_format($preco, 2) . "</td>";
                    echo "<td>R$ " . number_format($subtotal, 2) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='4'>Seu carrinho está vazio.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <?php if (!empty($itensDoCarrinho)) : ?>
    <div class="total">
        Total: R$ <?php echo number_format($total, 2); ?>
    </div>

    <button class="checkout-button">Finalizar Pedido</button>
    <?php endif; ?>
</div>
</body>
</html>
