<?php
include("config.php"); // Inclua as configurações do banco de dados
include_once("userfunctions.php");

// Agora você pode usar a função getProfileInfo
$user_id = 4; // Suponha que você tenha o ID do usuário atual

// Passe a conexão $mysqli como o segundo argumento
$profileInfo = getProfileInfo($user_id, $mysqli);

// Resto do seu código
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FFC081;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; /* Centralize horizontalmente */
            align-items: center; /* Centralize verticalmente */
            min-height: 100vh; /* Garante que a página ocupe a altura total da janela do navegador */
        }

        .container {
            max-width: 600px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            color: #777;
            margin-bottom: 20px;
        }

        form {
            text-align: center;
        }

        button {
            background-color: #FF0000;
            color: #fff;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #CC0000;
        }

        a {
            text-decoration: none;
            color: #007BFF;
            display: inline-block;
            margin-top: 10px;
        }
    </style>
    <title>Excluir Perfil</title>
</head>
<body>
    <div class="container">
        <h1>Excluir Perfil</h1>
        <?php
        // Inclua a configuração do banco de dados e a função getProfileInfo aqui
        include("config.php");
        include("userfunctions.php");

        // Suponha que você tenha o ID do usuário atual
        $user_id = 4;

        // Obtenha os detalhes do perfil
        $profileInfo = getProfileInfo($user_id, $mysqli);

        if ($profileInfo) {
            // Exiba o aviso com base nas informações do perfil
            echo "<p>Tem certeza de que deseja excluir o perfil de <strong>" . $profileInfo['nome'] . "</strong>?</p>";
            echo "<p>Esta ação não pode ser desfeita.</p>";
        } else {
            echo "Perfil não encontrado.";
        }
        ?>
        <form action="confirmar_exclusao.php" method="POST">
            <button type="submit">Confirmar Exclusão</button>
        </form>
        <a href="perfil.php">Cancelar</a>
    </div>
</body>
</html>
