<!DOCTYPE html>
<html>
<head>
    <style>
    
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        #top-menu {
            position: fixed;
            top: 0;
            width: 100%;
            background-color: #F0E5CF;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            z-index: 1000;
        }
        /* Adicione estilo específico para a página de contato */
        .contact-container {
            margin-top: 150px; /* Dê espaço abaixo da barra de navegação */
            text-align: center;
        }
        .contact-form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .contact-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .contact-form input, .contact-form textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .contact-form button {
            background-color: #E87800;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }
    </style>
     <title>Contato</title>
</head>
<body>
<?php
include "menutop.php";

?>

<div class="contact-container">
    <div class="contact-form">
        <form action="processar_contato.php" method="POST">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="telefone">Telefone:</label>
            <input type="tel" id="telefone" name="telefone" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="cidade">Cidade:</label>
            <input type="text" id="cidade" name="cidade" required>

            <label for="assunto">Assunto:</label>
            <textarea id="assunto" name="assunto" rows="4" required></textarea>

            <button type="submit">Enviar</button>
        </form>
    </div>
</div>

</body>
</html>
