<?php
// Inclua a configuração do banco de dados
include("config.php");

// Inclua as funções de usuário (se necessário)
include("userfunctions.php");

// Verifique se o perfil pode ser excluído (por exemplo, verifique permissões)
// Suponha que você tenha o ID do usuário atual
$user_id = 1;

// Construa a consulta SQL para excluir o perfil
$query = "DELETE FROM usuarios WHERE user_id = $user_id";

// Execute a consulta SQL
$result = mysqli_query($conexao, $query);

if ($result) {
    // Redirecione para uma página de confirmação ou página inicial após a exclusão
    header("Location: index.php");
    exit;
} else {
    // Exiba uma mensagem de erro se a exclusão falhar
    echo "Erro ao excluir o perfil: " . mysqli_error($conexao);
}
?>
