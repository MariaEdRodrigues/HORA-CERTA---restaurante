<?php
// Inclua a configuração do banco de dados
include("config.php"); // Certifique-se de que isso esteja correto

// Inclua as funções de usuário (se necessário)
include("userfunctions.php");

// Inicie a sessão (se ainda não estiver iniciada)
session_start();

// Verifique se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    // Se o usuário não estiver logado, redirecione para a página de login
    header("Location: login.php");
    exit;
}

// Crie uma conexão com o banco de dados
$mysqli = new mysqli($db_host, $db_user, $db_password, $db_name);

// Verifique a conexão
if ($mysqli->connect_error) {
    die("Erro de conexão com o banco de dados: " . $mysqli->connect_error);
}

$user_id = $_SESSION['usuario_id'];

?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #FFC081;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; /* Centralize horizontalmente */
            align-items: center; /* Centralize verticalmente */
            min-height: 100vh; /* Garante que a página ocupe a altura total da janela do navegador */
        }

        .container {
            max-width: 600px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .profile-info {
            padding: 20px;
            border-bottom: 1px solid #ccc;
            text-align: left;
        }

        .profile-info p {
            font-size: 18px;
            margin: 10px 0;
        }

        .profile-actions {
            margin-top: 20px;
        }

        .profile-actions a {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            text-decoration: none;
            background-color: #F29F05;
            color: #fff;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .profile-actions a:hover {
            background-color: #D2691E;
        }

        /* Adicione estilos para centralizar a imagem */
        .profile-image {
            width: 100px; /* Defina a largura e a altura da imagem aqui */
            height: 100px;
            border-radius: 50%; /* Isso cria a forma redonda */
            overflow: hidden; /* Certifique-se de que a imagem esteja dentro da forma redonda */
            display: flex;
            justify-content: center; /* Centralize horizontalmente */
            align-items: center; /* Centralize verticalmente */
        }

        .profile-image img {
            width: 100px; /* Ajuste o tamanho da imagem conforme necessário */
            border-radius: 50%; /* Tornar a imagem redonda, se desejar */
        }

    </style>
    <title>Perfil do Usuário</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Perfil do Usuário</h1>
        <div class="profile-info">
            <?php
            // Chame a função para obter as informações do perfil
            $profile_data = getProfileInfo($user_id, $mysqli);

            if ($profile_data === "Perfil não encontrado") {
                echo "Perfil não encontrado.";
            } else {
                // Exiba as informações do perfil do usuário com nomes em negrito e espaço entre eles
                echo "<strong>Nome:</strong> " . $profile_data['nome'] . "<br><br>";
                echo "<strong>Email:</strong> " . $profile_data['email'] . "<br><br>";
                echo "<strong>Telefone:</strong> " . $profile_data['telefone'] . "<br><br>";
            }
            ?>
        </div>
        <div class="profile-actions">
            <a href="editarperfil.php">Editar Perfil</a>
            <a href="excluirperfil.php">Excluir Perfil</a>
        </div>
    </div>
</body>
</html>
