    <style>
        body {
            margin: 0;
            padding: 0;
        }

        #footer {
            background-color: #F6AD39;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        #logo {
            width: 100px;
            /* Defina o tamanho da logo */
            height: auto;
        }

        .social-icons {
            margin-top: 10px;
        }

        .social-icons a {
            margin: 0 10px;
            color: white;
            font-size: 20px;
            vertical-align: middle;
            /* Centraliza verticalmente */
        }

        .icones-sociais li {
            display: inline-block;
        }
    </style>

    <!-- Conteúdo da página aqui -->

    <div id="footer">
        <ul class="icones-sociais">
            <li><a href="https://www.facebook.com/horacertarest?mibextid=b06tZ0" target="_blank"><img src="img/facebook.png" alt="Icone do Facebook"></a></li>
            <li><a href="https://l.wl.co/l?u=https%3A%2F%2Finstagram.com%2Fhoracertarest_%3Figshid%3DMzNlNGNkZWQ4Mg%3D%3D" target="_blank"><img src="img/instagram.png" alt="Icone do Instagram"></a></li>
            <li><a href="https://wa.me/message/LL6VUJ6TMOFFF1" target="_blank"><img src="img/whats.png" alt="Icone do WhatsApp"></a></li>
        </ul>
        <p>© <?php echo date("Y"); ?> Restaurante Hora Certa. Todos os direitos reservados.</p>
    </div>

    <!-- Inclua as bibliotecas do FontAwesome para os ícones -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha384-x0qRmzfP5fxn5z1t1fGtMRtqJ8jwqM9aamS3d5B4kP5mtKjs5Pfv3t5W4p5FJFpF" crossorigin="anonymous"> -->
    </body>

    </html>